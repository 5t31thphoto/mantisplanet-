#pragma once
// Minimal M5Unified surface for the desktop harness: only what MantisPlanet touches.
#include "Arduino.h"
#include <vector>
struct Vec3 { float x, y, z; };
struct ImuData { Vec3 accel; Vec3 gyro; };
struct HostDisplay { void setRotation(int) {} void setBrightness(int) {} };
class M5Canvas;
extern M5Canvas* g_hostLastCanvas;   // last canvas whose buffer was handed out
class M5Canvas {
 public:
  M5Canvas(HostDisplay*) {}
  void setColorDepth(int d) { depth_ = d; }
  void setPsram(bool) {}
  void* createSprite(int w, int h) { w_ = w; h_ = h; buf_.assign((size_t)w * h, 0); return buf_.data(); }
  void* getBuffer() { g_hostLastCanvas = this; return buf_.empty() ? nullptr : buf_.data(); }
  void pushSprite(HostDisplay*, int, int) { pushes++; }
  int width() const { return w_; }
  int height() const { return h_; }
  const uint16_t* pixels() const { return buf_.data(); }
  long pushes = 0;
 private:
  int w_ = 0, h_ = 0, depth_ = 16;
  std::vector<uint16_t> buf_;
};
struct HostImu {
  ImuData data{{0, 0, 1}, {0, 0, 0}};
  bool isEnabled() { return true; }
  bool loadOffsetFromNVS() { return true; }
  bool update() { return true; }
  ImuData getImuData() { return data; }
};
struct HostPower { int last = 0; long changes = 0; void setVibration(int v) { if (v != last) changes++; last = v; } };
struct HostSpeaker {
  bool en = false; long blocks = 0;
  bool isEnabled() { return en; } bool begin() { en = true; return true; } void end() { en = false; }
  void setVolume(int) {} size_t isPlaying(int) { return 0; }
  bool playRaw(const int16_t*, size_t, uint32_t, bool, uint32_t, int, bool) { blocks++; return true; }
};
struct TouchDetail {
  int x = 0, y = 0; bool pressed = false, was = false, rel = false;
  bool isPressed() const { return pressed; } bool wasPressed() const { return was; } bool wasReleased() const { return rel; }
};
struct HostTouch {
  bool down = false, prev = false; int x = 160, y = 120;
  TouchDetail getDetail() { TouchDetail d; d.x = x; d.y = y; d.pressed = down; d.was = down && !prev; d.rel = !down && prev; return d; }
};
struct HostCfg { bool output_power = false, internal_imu = false, internal_mic = false, internal_spk = false; };
struct M5Class {
  HostDisplay Display; HostImu Imu; HostPower Power; HostSpeaker Speaker; HostTouch Touch;
  HostCfg config() { return {}; }
  void begin(HostCfg) {}
  void update() { Touch.prev = touchLatch; touchLatch = Touch.down; }
  bool touchLatch = false;
};
extern M5Class M5;
